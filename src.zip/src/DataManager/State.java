package DataManager;

public enum State {
    In,
    Out
}
