package DataManager;

public enum DBName {
    information,
    users
}